#' @description
#' This roclet is the workhorse of `roxygen`, producing the Rd files that
#' document that functions in your package.
