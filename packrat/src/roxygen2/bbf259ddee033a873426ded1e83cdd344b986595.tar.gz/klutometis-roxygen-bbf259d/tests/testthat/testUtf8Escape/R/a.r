#' Title
#'
#' @param b Some label
a <- function(b = '7°C') 1
